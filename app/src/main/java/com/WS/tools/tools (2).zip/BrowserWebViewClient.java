package com.WS.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.http.SslError;
import android.os.Build;
import android.os.Message;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class BrowserWebViewClient extends WebViewClient {
    private final Activity activity;
    
    public BrowserWebViewClient(Activity activity) {
        this.activity = activity;
    }
    
    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        view.loadUrl("file:///android_asset/error.html");
    }
    
    @Override
    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        // Allow continuing (testing environment only!)
        handler.proceed();
    }
    
    @Override
    public void onFormResubmission(WebView view, Message dontResend, Message resend) {
        // Ask user about resubmitting the form
        new AlertDialog.Builder(activity)
                .setTitle("警告")
                .setMessage("是否重新提交表单？")
                .setPositiveButton("确定", (dialog, which) -> resend.sendToTarget())
                .setNegativeButton("取消", (dialog, which) -> dontResend.sendToTarget())
                .show();
    }
    
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return true;
    }
}