package com.WS.tools;

import android.app.DownloadManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class FileDownloadManager {

    public static void downloadFile(Context context, String url, String userAgent,
                                    String contentDisposition, String mimeType) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setMimeType(mimeType);
        request.addRequestHeader("User-Agent", userAgent);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                URLUtil.guessFileName(url, contentDisposition, mimeType));

        DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm != null) {
            dm.enqueue(request);
            Toast.makeText(context, "开始下载...", Toast.LENGTH_SHORT).show();
        }
    }

    public static void downloadImage(Context context, String imageUrl) {
        Toast.makeText(context, "正在下载图片...", Toast.LENGTH_SHORT).show();
        downloadFile(context, imageUrl, "WebView",
                "attachment", getMimeType(imageUrl));
    }

    public static void saveDataUrlToFile(Context context, String dataUrl, String fileName) {
        try {
            if (dataUrl != null && dataUrl.startsWith("data:")) {
                String mimeType = "application/octet-stream";
                if (dataUrl.contains(";")) {
                    mimeType = dataUrl.substring(5, dataUrl.indexOf(";"));
                }

                String base64Data = dataUrl.substring(dataUrl.indexOf(",") + 1);
                byte[] decodedData = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);

                // 使用 JavaScript 传入的原始文件名
                String originalFileName = fileName;

                // 确保文件名有正确的扩展名
                String extension = getExtensionFromMimeType(mimeType);
                if (extension != null && !extension.isEmpty()) {
                    if (!originalFileName.endsWith("." + extension)) {
                        fileName = originalFileName + "." + extension;
                    } else {
                        fileName = originalFileName;
                    }
                } else {
                    fileName = originalFileName;
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveFileUsingMediaStore(context, decodedData, fileName, mimeType);
                } else {
                    saveFileDirectly(context, decodedData, fileName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "下载失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static void saveFileUsingMediaStore(Context context, byte[] data, String fileName, String mimeType) throws Exception {
        ContentValues values = new ContentValues();
        // 修复：显式设置原始文件名，不让系统自动生成
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);

        // 确保 MIME 类型正确
        if (mimeType == null || mimeType.equals("application/octet-stream")) {
            mimeType = getMimeType(fileName);
        }
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        // Android 10+ 需要额外设置 IS_PENDING 标志
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Downloads.IS_PENDING, 1);
        }

        ContentResolver resolver = context.getContentResolver();
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri != null) {
            OutputStream os = resolver.openOutputStream(uri);
            if (os != null) {
                os.write(data);
                os.close();

                // Android 10+ 完成写入后清除 IS_PENDING 标志
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    resolver.update(uri, values, null, null);
                }

                Toast.makeText(context, "文件已保存到下载目录: " + fileName, Toast.LENGTH_LONG).show();
            }
        }
    }

    private static void saveFileDirectly(Context context, byte[] data, String fileName) throws Exception {
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs();
        }

        File file = new File(downloadsDir, fileName);
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(data);
        fos.close();

        Toast.makeText(context, "文件已下载到" + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
    }

    public static String getMimeType(String fileUrl) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(fileUrl);
        if (extension != null) {
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase());
        }
        return "application/octet-stream";
    }

    // 新增：从 MIME 类型获取扩展名
    private static String getExtensionFromMimeType(String mimeType) {
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        String extension = mimeTypeMap.getExtensionFromMimeType(mimeType);

        // 常见 MIME 类型的手动映射，以防 MimeTypeMap 未包含
        if (extension == null) {
            if (mimeType.equals("image/jpeg") || mimeType.equals("image/jpg")) return "jpg";
            if (mimeType.equals("image/png")) return "png";
            if (mimeType.equals("image/gif")) return "gif";
            if (mimeType.equals("audio/mpeg")) return "mp3";
            if (mimeType.equals("audio/mp4") || mimeType.equals("audio/mp4a-latm")) return "m4a";
            if (mimeType.equals("video/mp4")) return "mp4";
            if (mimeType.equals("application/pdf")) return "pdf";
            if (mimeType.equals("text/plain")) return "txt";
        }

        return extension;
    }
}