package com.WS.tools;

import android.content.Context;
import com.koushikdutta.async.http.server.AsyncHttpServer;
import java.io.InputStream;
import java.net.URLConnection;

public class LocalAssetServer {
    private static AsyncHttpServer server;
    private static int port = 8270;

    public static void start(Context context) {
        if (server != null) return;

        server = new AsyncHttpServer();
        server.get("/.*", (request, response) -> {
            try {
                String path = request.getPath().replaceFirst("/", "");
                if (path.isEmpty()) path = "index.html";

                InputStream is = context.getAssets().open(path);
                String mime = URLConnection.guessContentTypeFromName(path);
                response.sendStream(is, is.available());
                response.setContentType(mime != null ? mime : "text/plain");
            }
            catch (Exception e) {
                response.code(404);
                response.end();
            }
        });

        server.listen(port);
    }

    public static void stop() {
        if (server != null) {
            server.stop();
            server = null;
        }
    }

    public static String getLocalUrl() {
        return "http://localhost:" + port + "/";
    }
}
