package com.WS.tools;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class WebViewManager {
    private final Activity activity;
    private final WebView webView;
    private ValueCallbackListener filePathCallbackListener;
    private ChildWebViewListener childWebViewListener;

    public interface ValueCallbackListener {
        void onValueCallback(ValueCallback<Uri[]> callback);
    }

    public interface ChildWebViewListener {
        void onChildWebView(WebView webView);
    }

    public WebViewManager(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    public void setFilePathCallbackListener(ValueCallbackListener listener) {
        this.filePathCallbackListener = listener;
    }

    public void setChildWebViewListener(ChildWebViewListener listener) {
        this.childWebViewListener = listener;
    }

    @SuppressLint("SetJavaScriptEnabled")
    public void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        configureWebSettings(webSettings);
        setupCookieManager();
        setupWebViewClient();
        setupWebChromeClient();
        setupDownloadListener();
        setupJavaScriptInterface();
    }

    private void configureWebSettings(WebSettings webSettings) {
        // Basic settings
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAppCacheEnabled(true);
        webSettings.setAppCachePath(activity.getApplicationContext().getCacheDir().getAbsolutePath());

        // Advanced settings
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setSupportMultipleWindows(true);
        webSettings.setGeolocationEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setAllowFileAccessFromFileURLs(true);

        // Version-specific settings
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        }
    }

    private void setupCookieManager() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }
    }

    private void setupWebViewClient() {
        webView.setWebViewClient(new BrowserWebViewClient(activity));
    }

    private void setupWebChromeClient() {
        ProgressBar progressBar = activity.findViewById(R.id.progressBar);
        BrowserChromeClient chromeClient = new BrowserChromeClient(
                activity,
                progressBar,
                webView,
                callback -> {
                    if (filePathCallbackListener != null) {
                        filePathCallbackListener.onValueCallback(callback);
                    }
                },
                childWebView -> {
                    if (childWebViewListener != null) {
                        childWebViewListener.onChildWebView(childWebView);
                    }
                }
        );
        webView.setWebChromeClient(chromeClient);
    }

    private void setupDownloadListener() {
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url.startsWith("blob:")) {
                handleBlobDownload(url, contentDisposition, mimeType);
            } else {
                FileDownloadManager.downloadFile(activity, url, userAgent, contentDisposition, mimeType);
            }
        });
    }

    private void handleBlobDownload(String url, String contentDisposition, String mimeType) {
        webView.evaluateJavascript(
                "(function() {" +
                        "    var xhr = new XMLHttpRequest();" +
                        "    xhr.open('GET', '" + url + "', true);" +
                        "    xhr.responseType = 'blob';" +
                        "    xhr.onload = function(e) {" +
                        "        if (this.status == 200) {" +
                        "            var blob = this.response;" +
                        "            var reader = new FileReader();" +
                        "            reader.readAsDataURL(blob);" +
                        "            reader.onloadend = function() {" +
                        "                window.HTMLOUT.processDataUrl(reader.result, '" +
                        URLUtil.guessFileName(url, contentDisposition, mimeType) + "');" +
                        "            }" +
                        "        }" +
                        "    };" +
                        "    xhr.send();" +
                        "})();",
                null
        );
    }

    private void setupJavaScriptInterface() {
        webView.addJavascriptInterface(new JSInterface(activity), "HTMLOUT");
    }
}