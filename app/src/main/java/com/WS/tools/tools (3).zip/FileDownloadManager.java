package com.WS.tools;

import android.app.DownloadManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class FileDownloadManager {

    public static void downloadFile(Context context, String url, String userAgent,
                                   String contentDisposition, String mimeType) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
        request.setMimeType(mimeType);
        request.addRequestHeader("User-Agent", userAgent);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                URLUtil.guessFileName(url, contentDisposition, mimeType));

        DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm != null) {
            dm.enqueue(request);
            Toast.makeText(context, "开始下载...", Toast.LENGTH_SHORT).show();
        }
    }

    public static void downloadImage(Context context, String imageUrl) {
        // Implement image download logic here
        Toast.makeText(context, "正在下载图片...", Toast.LENGTH_SHORT).show();

        // Can use the downloadFile method or implement specific image download logic
        downloadFile(context, imageUrl, "WebView",
                     "attachment", getMimeType(imageUrl));
    }

    public static void saveDataUrlToFile(Context context, String dataUrl, String fileName) {
        try {
            if (dataUrl != null && dataUrl.startsWith("data:")) {
                String base64Data = dataUrl.substring(dataUrl.indexOf(",") + 1);
                byte[] decodedData = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    saveFileUsingMediaStore(context, decodedData, fileName);
                } else {
                    saveFileDirectly(context, decodedData, fileName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(context, "下载失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private static void saveFileUsingMediaStore(Context context, byte[] data, String fileName) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, getMimeType(fileName));
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        ContentResolver resolver = context.getContentResolver();
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri != null) {
            OutputStream os = resolver.openOutputStream(uri);
            if (os != null) {
                os.write(data);
                os.close();
                Toast.makeText(context, "文件已保存到下载目录: " + fileName, Toast.LENGTH_LONG).show();
            }
        }
    }

    private static void saveFileDirectly(Context context, byte[] data, String fileName) throws Exception {
        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!downloadsDir.exists()) {
            downloadsDir.mkdirs();
        }

        File file = new File(downloadsDir, fileName);
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(data);
        fos.close();

        Toast.makeText(context, "文件已下载到" + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
    }

    public static String getMimeType(String fileUrl) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(fileUrl);
        if (extension != null) {
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return "application/octet-stream";
    }
}